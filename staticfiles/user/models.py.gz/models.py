from statistics import mode
import django
from django.db import models
# Create your models here.
